import React from "react";

const Fifthpage = () =>{
    return(
        <div className="group-4">
                <div className="main-text-3">
                <p className="title-8">Priorities go first</p>
                <p className="body-text-6">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                    tempor incididunt ut labore
                    <br />
                    et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
                    exercitation ullamco laboris nisi ut
                </p>
                </div>
                <div className="row-3 match-height group">
                <div className="square-1">
                    <div className="text-3">
                    <p className="title-9">company</p>
                    <p className="body-text-7">
                        “Lorem ipsum dolor
                        <br />
                        sit amet, consectetur
                        <br />
                        adipisicing elit sed do”.
                    </p>
                    <div className="row-7 group">
                        <img
                        className="vector-smart-object3-double-click-to-edit-2"
                        src="images/vector_smart_object3_doub.png"
                        alt=""
                        width={61}
                        height={61}
                        />
                        <div className="col-14">
                        <p className="name">adam johns</p>
                        <p className="position">account manager</p>
                        </div>
                    </div>
                    </div>
                </div>
                <div className="square-2">
                    <div className="text-4">
                    <p className="title-10">company</p>
                    <p className="body-text-8">
                        “Lorem ipsum dolor
                        <br />
                        sit amet, consectetur
                        <br />
                        adipisicing elit sed do”.
                    </p>
                    <p className="name-2">adam johns</p>
                    <p className="position-2">account manager</p>
                    </div>
                    <img
                    className="vector-smart-object3-double-click-to-edit-3"
                    src="images/vector_smart_object3_doub.png"
                    alt=""
                    width={61}
                    height={61}
                    />
                </div>
                <div className="square-3">
                    <div className="text-5">
                    <p className="title-11">company</p>
                    <p className="body-text-9">
                        “Lorem ipsum dolor
                        <br />
                        sit amet, consectetur
                        <br />
                        adipisicing elit sed do”.
                    </p>
                    <p className="name-3">adam johns</p>
                    <p className="position-3">account manager</p>
                    </div>
                    <img
                    className="vector-smart-object3-double-click-to-edit-4"
                    src="images/vector_smart_object3_doub.png"
                    alt=""
                    width={61}
                    height={61}
                    />
                </div>
                </div>
            </div>
            
    )
}
export default Fifthpage