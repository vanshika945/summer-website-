import React from "react";

const Sixthpage = () =>{
    return(
      
            <div className="l-constrained">
                <p className="title-12">What exactly do we do</p>
                <p className="body-text-10">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
                veniam, quis
                </p>
                <img className="rectangle-5" src="images/rectangle_5.jpg" alt="" />
                <div className="row-2 group">
                <p className="projects">Projects</p>
                <p className="travel">Travel</p>
                <p className="mission">Mission</p>
                <p className="photos">Photos</p>
                </div>
                <div className="group-7 group">
                <div className="row group">
                    <img
                    className="place-your-design-here-double-click-to-edit"
                    src="images/place_your_design_here_do_7.png"
                    alt=""
                    width={719}
                    height={356}
                    />
                    <img
                    className="place-your-design-here-double-click-to-edit-2"
                    src="images/place_your_design_here_do_6.png"
                    alt=""
                    width={721}
                    height={356}
                    />
                </div>
                <img className="rectangle-6" src="images/rectangle_5.jpg" alt="" />
                </div>
                <div className="group-8">
                <div className="text-6">
                    <p className="text-7">“</p>
                    <p className="body-text-11">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
                    eiusmod tempor
                    <br />
                    incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                    quis
                    </p>
                    <p className="name-4">David Johnson</p>
                </div>
                </div>
            </div>
    )
}
export default Sixthpage