import React from "react";

const Twelvethpage = () =>{
    return(
        <div className="group-14">
                <div className="text-20">
                <div className="text-21 group">
                    <div className="main-text-4">
                    <p className="title-21">about</p>
                    <p className="body-text-20">
                        Lorem ipsum dolor sit amet, consec tetur adipisicing elit, sed do
                        eiusmod tempor incididunt ultimam quantum
                    </p>
                    </div>
                    <div className="column-3">
                    <p className="about-4">about</p>
                    <p className="team-3">Team</p>
                    <p className="text-24">Join us</p>
                    <p className="ethic-3">Ethic</p>
                    <p className="goals-3">Goals</p>
                    </div>
                    <div className="column-2">
                    <p className="about-3">about</p>
                    <p className="team-2">Team</p>
                    <p className="text-23">Join us</p>
                    <p className="ethic-2">Ethic</p>
                    <p className="goals-2">Goals</p>
                    </div>
                    <div className="column-1">
                    <p className="about-2">about</p>
                    <p className="team">Team</p>
                    <p className="text-22">Join us</p>
                    <p className="ethic">Ethic</p>
                    <p className="goals">Goals</p>
                    </div>
                </div>
                </div>
            </div>
    )
}
export default Twelvethpage 