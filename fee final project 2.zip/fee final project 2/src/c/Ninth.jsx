import React from "react";

const Ninthpage = () =>{
    return(
        <div className="l-constrained-2">
        <div className="row-8 group">
        <div className="text-1">
            <p className="title-15">Projects / 20th August</p>
            <p className="subtitle-2">Something new has just arrived</p>
            <p className="body-text-16">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
            minim v architecto beatae vitae dicta sunt es. omne essentiale dolor
            liquam.
            </p>
        </div>
        <img
            className="place-your-design-here-double-click-to-edit-4"
            src="images/place_your_design_here_do_3.png"
            alt=""
            width={323}
            height={380}
        />
        </div>
        <div className="row-9 group">
        <img
            className="place-your-design-here-double-click-to-edit-5"
            src="images/place_your_design_here_do_2.png"
            alt=""
            width={570}
            height={380}
        />
        <div className="text-2-2">
            <p className="title-16">Projects / 20th August</p>
            <p className="subtitle-3">Something new has just arrived</p>
            <p className="body-text-17">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
            minim v architecto beatae vitae dicta sunt es. omne essentiale dolor
            liquam.
            </p>
        </div>
        </div>
        <div className="row-10 group">
        <div className="text-3-2">
            <p className="title-17">Projects / 20th August</p>
            <p className="subtitle-4">Something new has just arrived</p>
            <p className="body-text-18">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
            minim v architecto beatae vitae dicta sunt es. omne essentiale dolor
            liquam.
            </p>
        </div>
        <img
            className="place-your-design-here-double-click-to-edit-6"
            src="images/place_your_design_here_do.png"
            alt=""
            width={570}
            height={380}
        />
        </div>
    </div>
    )
}
export default Ninthpage